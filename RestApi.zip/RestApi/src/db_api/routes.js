const { Router } = require('express');

const controller = require('./controller')

const router = Router();

//cuando se ejecute un metodo http
router.get("/", controller.getProducto);
router.post("/", controller.addProducto);
router.get("/:id", controller.getProductoByID);
router.put("/:id", controller.updateProducto);
router.delete("/:id", controller.removeProducto);


module.exports = router;

