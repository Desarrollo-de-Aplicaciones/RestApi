//importacion los demas modulos
const pool = require('../../db');
const queries = require('./queries');


const getProducto = (req, res) => {
    pool.query(queries.getProduct, (error, results) => {

        if(error) throw error;
        res.status(200).json(results.rows);
    });
};

const getProductoByID = (req, res) => {
    const id = parseInt(req.params.id);
    pool.query(queries.getProductoByID, [id], (error, results) => {

        if(error) throw error;
        res.status(200).json(results.rows);
    });
};

//Añadir Producto a la BD
const addProducto = (req, res) => {
    const {ID, producto, precio, descripcion} = req.body;

    //validamos si el ID Existe
    pool.query(queries.VerificarIDExiste, [ID], (error, results) =>{

        if (results.rows.length){
            res.send("El producto ya existe.");
        }

        //Si no existe lo añadimos a la DB
        pool.query(queries.addProducto, [ID, producto, precio, descripcion], (error, results) =>{
            if(error) throw error;
            //el estado 201 es que ha sido creado exitosamente
            res.status(201).send("Producto creado exitosamente")
        });
    });
};

const removeProducto = (req, res) => {
    const id = parseInt(req.params.id);

    pool.query(queries.removeProducto, [id], (error, results) =>{
        //si no encuentra un producto
        const ProductoNoEncontrado = !results.rows.length;

        if(ProductoNoEncontrado){    
        res.send("El producto no existe en la Base de Datos"); 
        }
        
        //remover el producto
        pool.query(queries.removeProducto, [id],(error, results) =>{
        if(error) throw error;
        res.status(200).send("El producto se ha eliminado");
        });
    });
};

const updateProducto = (req, res) => {
    const id = parseInt(req.params.id);
    const { producto } = req.body;

    pool.query(queries.getProduct, [id],  (error, results) => {

        //si no encuentra un producto
        const ProductoNoEncontrado = !results.rows.length;

        if(ProductoNoEncontrado){    
        res.send("El producto no existe en la Base de Datos"); 
        }

        pool.query(queries.updateProducto, [producto], (error, results) => {
            if (error) throw error;
            res.status(200).send("El producto ha sido Actualizado");
        });
    });
};


//Aqui exportamos los modulos de otros archivos que utilizaremos
module.exports = {
    getProducto,
    getProductoByID,
    addProducto,
    removeProducto,
    updateProducto,
};



