//Aqui tendremos los querys para la base de datos

const getProduct = "SELECT * FROM Producto";
const getProductByID = "SELECT * FROM Producto WHERE ID = $1";
const VerificarIDExiste = "SELECT s FROM Producto s WHERE s.ID = $1";
const addProducto = "INSERT INTO producto (ID, producto, precio, descripcion) VALUES ($1, $2, $3, $4)";
const removeProducto = "DELETE FROM Producto WHERE ID = $1";
//Los parametros $1 y $2 del pool.query los colocamos aquí
const updateProducto = "UPDATE Producto SET producto = $1 WHERE ID = $2";


//Aqui exportamos a los demas modulos lo que ocupemos
module.exports = {
    getProduct,
    getProductByID,
    VerificarIDExiste,
    removeProducto,
};
