//Aqui es donde vamos a crear el sevridor express

const express = require('express');
const db_apiRoutes = require("./src/db_api/routes");


//app es nuestro servidor, almacena un objeto
const app = express();
const port = 3000;


app.use(express.json());

//cuando obtengamos un metodo get 
app.get("/", (req, res) => {
    res.send("Ricardita Milos");
});

app.use('/api/v1/Producto', db_apiRoutes);

app.listen(port, () => console.log(`app listening on port ${port}`));
