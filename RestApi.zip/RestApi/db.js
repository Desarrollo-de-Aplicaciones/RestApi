//Aqui es donde haremos la conexion al Progrest 

const Pool = require("pg").Pool;

const pool = new Pool({
    user: "postgres",
    host: "localhost",
    database: "db_api",
    password: "Api123",
    port: 5432,
});

module.exports = pool;
